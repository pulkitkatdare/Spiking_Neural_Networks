M=5000;
format long e
Output_V=zeros(1,M);
Output_U=zeros(1,M);
lambda=10;
sum = 0;
I_o=1e-12;
w_e=500;
T_W=15;
T_W1=T_W/4;
time=linspace(1,5000,5000);

y = zeros(1,5000);
while sum<=5000
    n=poissrnd(lambda);
    n=floor(10000*(1/n));
    sum=sum+n;
    if sum>5000
    break
    end
    y(sum)=1;

end
plot(time,y)
Current=zeros(1,5000);
for i = 1:5000
for j=1:i
if y(j)==1
Current(i)=I_o*w_e*(exp(-(i-j)/T_W)-exp(-(i-j)/T_W1))+Current(i);

end

end
end
%code for Problem 3C in assignment-I for EE746 
t=500e-3;
M=5000;
del_t=0.1e-3;
C=200e-12;
g_L=10e-9;
E_l=-70e-3;
V_T=-50e-3;
del_T=2e-3;
a=2e-9;
t_w=30e-3;
b=0;
V_r=-58e-3;
V_steady=0;
V_steady_previous=0;
U_steady=0;
V_steady=V_steady-((g_L*del_T*exp((V_steady-V_T)/del_T)-(g_L+a)*(V_steady-E_l))/(g_L*exp((V_steady-V_T)/del_T)-(g_L+a)));
    
while abs(V_steady-V_steady_previous)>10e-6  
V_steady_previous=V_steady;
V_steady=V_steady-((g_L*del_T*exp((V_steady-V_T)/del_T)-(g_L+a)*(V_steady-E_l))/(g_L*exp((V_steady-V_T)/del_T)-(g_L+a)));
end
U_steady=a*(V_steady-E_l);

C_inverse=1/C;
G_L=g_L;
E_L=E_l;
E_T=V_T;
delta_T=del_T;
A=a;
T_W=1/t_w;
B=b;
V_R=V_r;
G=zeros(1,1);
G=E_l;
U_t=0;
inverse_delta_T=1/del_T;
del_V=0;
for i=1:M
del_V=C_inverse*((-G_L*(G - E_L)+G_L*delta_T*exp((G - E_T)*inverse_delta_T) -U_t + Current(i)));
del_U=(a*(G-E_L)-U_t)*(T_W);
G=G+del_V*del_t;
U_t=U_t+del_U*del_t;
if G > 0
    G=V_R;
    U_t=U_t+B;
end
Output_V(:,i)=G;
Output_U(:,i)=U_t;
end

plot(time,Output_V);