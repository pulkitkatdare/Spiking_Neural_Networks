lambda=10;
sum = 0;
I_o=1e-12;
w_e=500;
T_W=15;
T_W1=T_W/4;
time=linspace(1,5000,5000);
y = zeros(1,5000);
while sum<=5000
    n=poissrnd(lambda);
    n=floor(10000*(1/n));
    sum=sum+n;
    if sum>5000
    break
    end
    y(sum)=1;

end
plot(time,y)
Current=zeros(1,5000);
for i = 1:5000
for j=1:i
if y(j)==1
Current(i)=I_o*w_e*(exp(-(i-j)/T_W)-exp(-(i-j)/T_W1))+Current(i);

end

end
end
plot(time,Current);