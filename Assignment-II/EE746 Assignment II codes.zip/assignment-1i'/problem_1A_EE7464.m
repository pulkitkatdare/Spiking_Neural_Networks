lambda=10;
sum = 0;
time=linspace(0,5000,5001);
y = zeros(1,5001);
while sum<=5000
    n=poissrnd(lambda);
    n=floor(10000*(1/n));
    sum=sum+n;
    if sum>5000
    break
    end
    y(sum)=1;

end
plot(time,y)