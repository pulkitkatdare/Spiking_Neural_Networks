format long e
M=5000;
lambda=5;
gamma=1;
I_o=1e-12;
T_W=15;
T_W1=T_W/4;
W_o=200;
N_s=100;
sigma_w=20;
W_e=normrnd(W_o,sigma_w,100,1);
time=linspace(1,5000,5000);
y = zeros(N_s,5000);
y2 = zeros(N_s,5000);
M=5000;
del_t=0.1e-3;
C=200e-12;
g_L=10e-9;
E_l=-70e-3;
V_T=-50e-3;
del_T=2e-3;
a=2e-9;
t_w=30e-3;
b=0;
V_r=-58e-3;
C_inverse=1/C;
G_L=g_L;
E_L=E_l;
E_T=V_T;
delta_T=del_T;
B=b;
V_R=V_r;
for count=1:N_s
    sum=0;
while sum<=5000
    n=poissrnd(lambda);
    n=floor(10000.*(1./n));
    sum=sum+n;
    if sum>5000
    break
    end
    y(count,sum)=1;

end
end
for count=1:N_s
    sum=0;
while sum<=5000
    n=poissrnd(lambda);
    n=floor(10000.*(1./n));
    sum=sum+n;
    if sum>5000
    break
    end
    y2(count,sum)=1;

end
end
Input_O=zeros(N_s,5000);
T_W=15;
for count=1:N_s
for i = 1:5000
for j=1:i
if y(count,j)==1
Input_O(count,i)=I_o*W_e(count)*(exp(-(i-j)/T_W)-exp(-(i-j)/T_W1))+Input_O(count,i);

end

end
end
end
Input=zeros(1,5000);
for count=1:N_s
Input=Input+Input_O(count,:);
end
t_w=30e-3;
T_W=1/t_w;
G=E_l;
U_t=0;
inverse_delta_T=1/delta_T;
t_nos=zeros(1,80);
number=0;
Output_V=zeros(1,5000);
Output_U=zeros(1,5000);
for i=1:M
del_V=C_inverse*((-G_L*(G - E_L)+G_L*delta_T*exp((G - E_T)*inverse_delta_T) -U_t+Input(i)));
del_U=(a*(G-E_L)-U_t)*(T_W);
G=G+del_V*del_t;
U_t=U_t+del_U*del_t;
if G >= 0
    number=number+1;
    t_nos(number)=i;
    G=V_R;
    U_t=U_t+B;
end
Output_V(:,i)=G;
Output_U(:,i)=U_t;
end;
spikenumber=1;
countnumber=0;
number2=1;
while number2 ~= 0
    1
while number~=0 
    T_W=15;
    countnumber=countnumber+1;
    del_W_e=zeros(100,number);
    del_t_k=zeros(100,number);
for count= 1:N_s
for j=1:number    
for i=1:t_nos(j)
if y(count,i)==1
del_t_k(count,j)=(t_nos(j)-i)*0.1;
end

end
del_W_e(count,j)=-W_e(count)*gamma*(exp(-del_t_k(count,j)/T_W)-exp(-del_t_k(count,j)/T_W1));
W_e(count)=del_W_e(count,j)+W_e(count);
end
end
Input_O=zeros(N_s,5000);
for count=1:N_s
for i = 1:5000
for j=1:i
if y(count,j)==1
Input_O(count,i)=I_o*W_e(count)*(exp(-(i-j)/T_W)-exp(-(i-j)/T_W1))+Input_O(count,i);
end
end
end
end
Input=zeros(1,5000);
for count=1:N_s
Input=Input+Input_O(count,:);
end
t_w=30e-3;
T_W=1/t_w;
G=E_l;
U_t=0;
inverse_delta_T=1/delta_T;
Output_V=zeros(1,5000);
Output_U=zeros(1,5000);
spikenumber=0;
number=0;
for i=1:M
del_V=C_inverse*((-G_L*(G - E_L)+G_L*delta_T*exp((G - E_T)*inverse_delta_T) -U_t+Input(i)));
del_U=(a*(G-E_L)-U_t)*(T_W);
G=G+del_V*del_t;
U_t=U_t+del_U*del_t;
if G >= 0
    n1=G;
    number=number+1;
    G=V_R;
    U_t=U_t+B;
end
Output_V(:,i)=G;
Output_U(:,i)=U_t;
end
%[v_max, t_max]=max(Output_V);
%figure
%plot(del_t_k,del_W_e,'o');
figure
plot(time,Output_V);
%plot(time,Output_V);
end
W_e2=W_e;
T_W=15;
Input_O=zeros(N_s,5000);
for count=1:N_s
for i = 1:5000
for j=1:i
if y2(count,j)==1
Input_O(count,i)=I_o*W_e2(count)*(exp(-(i-j)/T_W)-exp(-(i-j)/T_W1))+Input_O(count,i);

end

end
end
end
M=5000;
Output=zeros(1,M);
Input=zeros(1,5000);
for count=1:N_s
Input=Input+Input_O(count,:);
end
t_w=30e-3;
T_W=1/t_w;
G=E_l;
U_t=0;
inverse_delta_T=1/delta_T;
del_V=0;
t_nos=zeros(1,80);
number2=0;
for i=1:M
del_V=C_inverse*((-G_L*(G - E_L)+G_L*delta_T*exp((G - E_T)*inverse_delta_T) -U_t+Input(i)));
del_U=(a*(G-E_L)-U_t)*(T_W);
G=G+del_V*del_t;
U_t=U_t+del_U*del_t;
if G >= 0
    number2=number2+1;
    t_nos(number2)=i;
    G=V_R;
    U_t=U_t+B;
end
Output_V(:,i)=G;
Output_U(:,i)=U_t;
end
[v_max , t_max]= max(Output_V);
countnumber=0;
if number2 ~= 0
break
end
%while number2=0 && number==0
while number2 ==0 
    T_W=15;
    countnumber=countnumber+1
    del_W_e2=zeros(100,1);
    del_t_k2=zeros(100,1);
for count= 1:N_s
for i=1:t_max
if y2(count,i)==1
del_t_k2(count)=(t_max-i);

end

end
del_W_e2(count)=W_e2(count)*gamma*(exp(-del_t_k2(count)/T_W)-exp(-del_t_k2(count)/T_W1));
W_e2(count)=W_e2(count)*gamma*(exp(-del_t_k2(count)/T_W)-exp(-del_t_k2(count)/T_W1))+W_e2(count);
end

Input_O=zeros(N_s,5000);
for count=1:N_s
for i = 1:5000
for j=1:i
if y(count,j)==1
Input_O(count,i)=I_o*W_e2(count)*(exp(-(i-j)/T_W)-exp(-(i-j)/T_W1))+Input_O(count,i);
end
end
end
end
Output=zeros(1,M);
Input=zeros(1,5000);
for count=1:N_s
Input=Input+Input_O(count,:);
end
t=500e-3;
M=5000;
del_t=0.1e-3;
C=200e-12;
g_L=10e-9;
E_l=-70e-3;
V_T=-50e-3;
del_T=2e-3;
a=2e-9;
t_w=30e-3;
b=0;
V_r=-58e-3;
C_inverse=1/C;
G_L=g_L;
E_L=E_l;
E_T=V_T;
delta_T=del_T;
A=a;
T_W=1/t_w;
B=b;
V_R=V_r;
G=E_l;
U_t=0;
inverse_delta_T=1/delta_T;
del_V=0;
Output_V=zeros(1,5000);
Output_U=zeros(1,5000);
number2=0;
for i=1:M
del_V=C_inverse*((-G_L*(G - E_L)+G_L*delta_T*exp((G - E_T)*inverse_delta_T) -U_t+Input(i)));
del_U=(a*(G-E_L)-U_t)*(T_W);
G=G+del_V*del_t;
U_t=U_t+del_U*del_t;
if G >= 0
    number2=number2+1;
    G=V_R;
    U_t=U_t+B;
end
Output_V(:,i)=G;
Output_U(:,i)=U_t;
end

[v_max, t_max]=max(Output_V);
figure
plot(time,Output_V);

%plot(time,Output_V);
end
number=number2;
W_e=W_e2;
end