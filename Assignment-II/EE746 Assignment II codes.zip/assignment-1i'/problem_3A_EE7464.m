format long e
lambda=10;
gamma=1;
I_o=1e-12;
T_W=15;
T_W1=T_W/4;
W_o=50;
N_s=100;
sigma_w=5;
W_e=normrnd(W_o,sigma_w,100,1);
time=linspace(1,5000,5000);
y = zeros(N_s,5000);
for count=1:N_s
    sum=0;
while sum<=5000
    n=poissrnd(lambda);
    n=floor(10000.*(1./n));
    sum=sum+n;
    if sum>5000
    break
    end
    y(count,sum)=1;

end
end
figure
plot(time,y(1,:))
Input_O=zeros(N_s,5000);
for count=1:N_s
for i = 1:5000
for j=1:i
if y(count,j)==1
Input_O(count,i)=I_o*W_e(count)*(exp(-(i-j)*0.1/T_W)-exp(-(i-j)*0.1/T_W1))+Input_O(count,i);

end

end
end
end
M=5000;
Output=zeros(1,M);
Input=zeros(1,5000);
for count=1:N_s
Input=Input+Input_O(count,:);
end
t=500e-3;
M=5000;
del_t=0.1e-3;
C=200e-12;
g_L=10e-9;
E_l=-70e-3;
V_T=-50e-3;
del_T=2e-3;
a=2e-9;
t_w=30e-3;
b=0;
V_r=-58e-3;
V_steady=0;
V_steady_previous=0;
U_steady=0;
V_steady=V_steady-((g_L*del_T*exp((V_steady-V_T)/del_T)-(g_L+a)*(V_steady-E_l))/(g_L*exp((V_steady-V_T)/del_T)-(g_L+a)));
    
while abs(V_steady-V_steady_previous)>10e-6  
V_steady_previous=V_steady;
V_steady=V_steady-((g_L*del_T*exp((V_steady-V_T)/del_T)-(g_L+a)*(V_steady-E_l))/(g_L*exp((V_steady-V_T)/del_T)-(g_L+a)));
end
U_steady=a*(V_steady-E_l);

C_inverse=1/C;
G_L=g_L;
E_L=E_l;
E_T=V_T;
delta_T=del_T;
A=a;
T_W=1/t_w;
B=b;
V_R=V_r;
G=zeros(1,1);
G=E_l;
U_t=U_steady;
inverse_delta_T=1/delta_T;
del_V=0;
for i=1:M
del_V=C_inverse*((-G_L*(G - E_L)+G_L*delta_T*exp((G - E_T)*inverse_delta_T) -U_t+Input(i)));
del_U=(a*(G-E_L)-U_t)*(T_W);
G=G+del_V*del_t;
U_t=U_t+del_U*del_t;
if G > 0
    
    G=V_R;
    U_t=U_t+B;
end
Output_V(:,i)=G;
Output_U(:,i)=U_t;
end

[v_max, t_max]=max(Output_V);
spikenumber=0;
countnumber=0;
while spikenumber==0;
    T_W=15;
    countnumber=countnumber+1
    del_W_e=zeros(100,1);
    del_t_k=zeros(100,1);
    
for count= 1:N_s
for i=1:t_max
if y(count,i)==1
del_t_k(count)=(t_max-i)*0.1;

end

end
del_W_e(count)=W_e(count)*gamma*(exp(-del_t_k(count)/T_W)-exp(-del_t_k(count)/T_W1));
W_e(count)=W_e(count)*gamma*(exp(-del_t_k(count)/T_W)-exp(-del_t_k(count)/T_W1))+W_e(count);
end

Input_O=zeros(N_s,5000);
for count=1:N_s
for i = 1:5000
for j=1:i
if y(count,j)==1
Input_O(count,i)=I_o*W_e(count)*(exp(-(i-j)/T_W)-exp(-(i-j)/T_W1))+Input_O(count,i);
end
end
end
end
Output=zeros(1,M);
Input=zeros(1,5000);
for count=1:N_s
Input=Input+Input_O(count,:);
end
t=500e-3;
M=5000;
del_t=0.1e-3;
C=200e-12;
g_L=10e-9;
E_l=-70e-3;
V_T=-50e-3;
del_T=2e-3;
a=2e-9;
t_w=30e-3;
b=0;
V_r=-58e-3;
C_inverse=1/C;
G_L=g_L;
E_L=E_l;
E_T=V_T;
delta_T=del_T;
A=a;
T_W=1/t_w;
B=b;
V_R=V_r;
G=E_l;
U_t=U_steady;
inverse_delta_T=1/delta_T;
del_V=0;
Output_V=zeros(1,5000);
Output_U=zeros(1,5000);
for i=1:M
del_V=C_inverse*((-G_L*(G - E_L)+G_L*delta_T*exp((G - E_T)*inverse_delta_T) -U_t+Input(i)));
del_U=(a*(G-E_L)-U_t)*(T_W);
G=G+del_V*del_t;
U_t=U_t+del_U*del_t;
if G >= 0
    spikenumber=spikenumber+1;
    n1=G;
    G=V_R;
    U_t=U_t+B;
end
Output_V(:,i)=G;
Output_U(:,i)=U_t;
end

[v_max, t_max]=max(Output_V);
figure
plot(time,Output_V);
figure 
plot(del_t_k,del_W_e,'o')
end


